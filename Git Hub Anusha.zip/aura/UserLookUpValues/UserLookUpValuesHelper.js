({
	helperMethod : function(component, event) {
        var workRecord = component.get("v.WorkRecord");
        console.log('workRecord helper: '+workRecord);
		var action = component.get("c.getUsers");
        action.setParams({
            "woObj" : component.get("v.WorkRecord")
        });
        action.setCallback(this, function(response) {
            if(response.getState() == "SUCCESS"){
                console.log('getusers() '+response.getReturnValue());
                component.set("v.users",response.getReturnValue());
            }
        });        
        $A.enqueueAction(action); 
	}
})