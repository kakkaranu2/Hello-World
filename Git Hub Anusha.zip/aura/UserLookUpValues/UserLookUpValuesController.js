({
    doInit : function(component, event, helper) {
        
        var action = component.get("c.getUsers");
        action.setParams({
            "woObjID" : component.get("v.recordId")
        });
        action.setCallback(this, function(response) {
            if(response.getState() == "SUCCESS"){
                console.log('getusers() '+response.getReturnValue());
                component.set("v.users",response.getReturnValue());
            }
        });        
        $A.enqueueAction(action); 
    },
    
    onSelectChange : function(component, event, helper) {
        var selected = component.find("users").get("v.value");
        component.set("v.selectedUserId",selected);
    },
    cancel : function(component, event, helper) {
        $A.get("e.force:closeQuickAction").fire();
    },
    save : function(component, event, helper) {
        var action = component.get("c.setAssignedToInWorkOrder");
        action.setParams({
            workOrderId:component.get("v.recordId"),
            ownerId: component.get("v.selectedUserId")
        });         
        action.setCallback(this, function(response) {
            if(response.getState() == "SUCCESS"){
                //alert(response.getReturnValue());
            }
        });        
        $A.enqueueAction(action);
        $A.get("e.force:closeQuickAction").fire();  
        $A.get('e.force:refreshView').fire();
    }
})