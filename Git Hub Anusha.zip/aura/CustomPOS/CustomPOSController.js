({
    doInit : function(component, event, helper) {
        
        var action = component.get("c.getSigntype");
        action.setParams({
            WOID:component.get("v.recordId")
        }); 
        action.setCallback(this, function(response){
            if(response.getState() == "SUCCESS"){
                component.set("v.signTypeLst",response.getReturnValue());
            }
        });
        $A.enqueueAction(action); 
        
        var themeaction = component.get("c.getTheme");
        themeaction.setParams({
            WOID:component.get("v.recordId")
        }); 
        themeaction.setCallback(this, function(response){
            if(response.getState() == "SUCCESS"){
                component.set("v.themeLst",response.getReturnValue());
            }
        }); 
        $A.enqueueAction(themeaction);
        
        var sizeaction = component.get("c.getSize");
        sizeaction.setCallback(this, function(response){
            if(response.getState() == "SUCCESS"){
                component.set("v.sizeLst",response.getReturnValue());
            }
        });       
        $A.enqueueAction(sizeaction);
        
        var packageaction = component.get("c.getPackage");
        packageaction.setParams({
            WOID:component.get("v.recordId")
        }); 
        packageaction.setCallback(this, function(response){
            if(response.getState() == "SUCCESS"){
                component.set("v.packageLst",response.getReturnValue());
            }    
        });
        $A.enqueueAction(packageaction);
    },
    
    handleChange : function(component, event, helper){
        var radioGrpValue = component.get("v.radioGrpValue");
        console.log('@@@@'+radioGrpValue);
        if(radioGrpValue == 'Brand'){
            document.getElementById('BrandIDdiv').style.display = 'block';
            document.getElementById('BrandFamilyIDdiv').style.display = 'none';
        }
        if(radioGrpValue == 'Brand Family'){
            document.getElementById('BrandIDdiv').style.display = 'none';
            document.getElementById('BrandFamilyIDdiv').style.display = 'block';
        }
    },
    
    getBrand : function(component, event, helper){
        var selectedBrandVar = component.find("BrandID").get("v.value"); 
        component.set("v.selectedBrand",selectedBrandVar);
    },
    
    /*getBrandFamily : function(component, event, helper){
        var selectedBrandFamilyvar = component.find("BrandFamilyID").get("v.value");
        component.set("v.selectedBrandFamily",selectedBrandFamilyvar);
    },*/
    
    onPackageChange : function(component, event, helper){
        var onPackageChangeboolean = true;
        component.set("v.onPackageChangeboolean",onPackageChangeboolean);
        var selectedPackageVar = component.find('PackageID').get('v.value');
        component.set("v.selectedPackage",selectedPackageVar);
        var packaction = component.get('c.getSelectedPackage');
        packaction.setParams({
            "pckgID" : component.get('v.selectedPackage')
        }); 
        packaction.setCallback(this, function(response){
            if(response.getState() == "SUCCESS"){
                component.set("v.packageTypeLst",response.getReturnValue());
            }
        });       
        $A.enqueueAction(packaction);
    },
    
    onPackageTypeChange : function(component, event, helper){
        var selectedPackageTypevar = component.find('packageTypeID').get('v.value'); 
        component.set("v.selectedPackgType",selectedPackageTypevar); 
        var pckgTypeaction = component.get('c.getSelectedPckgType');
        pckgTypeaction.setParams({
            "pckgTypeID" : component.get('v.selectedPackgType')
        }); 
        pckgTypeaction.setCallback(this, function(response){
            if(response.getState() == "SUCCESS"){
                component.set("v.packageSizeLst",response.getReturnValue());
            }
        });       
        $A.enqueueAction(pckgTypeaction);
    },
    
    getSelectedPackgSize : function(component, event, helper){
        var selectedPackgSizevar = component.find('packageSizeID').get('v.value');
        component.set("v.selectedPackgSize",selectedPackgSizevar);
        var pckgSizeaction = component.get('c.getPckgSizeSelected');
        pckgSizeaction.setParams({
            "PckgsizeID" : component.get('v.selectedPackgSize')
        });
        pckgSizeaction.setCallback(this, function(response){
            if(response.getState() == "SUCCESS"){
                component.set("v.selectedPckgSizeNew",response.getReturnValue());
            }
        });       
        $A.enqueueAction(pckgSizeaction);
    },
    
    getPrice : function(component, event, helper){
        var selectedPriceVar = component.find("PriceID").get("v.value");
        component.set("v.selectedPrice",selectedPriceVar);
    },
    
    onSignTypeChange : function(component, event, helper){
        var selectedSignTypevar = component.find("sign").get("v.value");
        component.set("v.selectedSignType",selectedSignTypevar);
        var sizeaction = component.get("c.getSize");
        sizeaction.setParams({
            "SignType" : component.get("v.selectedSignType")
        });       
        sizeaction.setCallback(this, function(response){
            if(response.getState() == "SUCCESS"){
                component.set("v.sizeLst",response.getReturnValue());
            }
        });       
        $A.enqueueAction(sizeaction);
        
        var checkboxVal = component.get("c.getCheckBoxVal");
        checkboxVal.setParams({
            "SignType" : component.get("v.selectedSignType")
        });
        checkboxVal.setCallback(this, function(response){
            if(response.getState() == "SUCCESS"){
                component.set("v.checkBoxOptions",response.getReturnValue());
                var temp = JSON.stringify(component.get("v.checkBoxOptions"));
                console.log('temp.....'+temp);
            }
        });       
        $A.enqueueAction(checkboxVal);
    },
    
    onThemeChange : function(component, event, helper){
        var selectedThemevar = component.find("ThemeID").get("v.value");
        component.set("v.selectedTheme",selectedThemevar);
    },
    
    getSelectedSize : function(component, event, helper){
        var selectedSizevar = component.find('signID').get('v.value');
        component.set('v.selectedSize',selectedSizevar);
        var sizeaction = component.get('c.getSizeSelected');
        sizeaction.setParams({
            "sizeID" : component.get('v.selectedSize')
        });       
        sizeaction.setCallback(this, function(response){
            if(response.getState() == "SUCCESS"){
                component.set("v.selectedSizeNew",response.getReturnValue());
            }
        });       
        $A.enqueueAction(sizeaction);
    },
    
    getQty : function(component, event, helper){
        var selectedQtyvar = component.find("QtyID").get("v.value");
        component.set("v.selectedQty",selectedQtyvar);
    },
    
    checkBoxSel : function(component, event, helper){
        var checkBoxVal = component.get('c.selectedChckBoxVal');
        checkBoxVal.setParams({
            "Options" : JSON.stringify(component.get('v.checkBoxOptions'))
        }); 
        checkBoxVal.setCallback(this, function(response){
            if(response.getState() == "SUCCESS"){
                component.set("v.selectCheckBoxvalue",response.getReturnValue());
                var temp = component.get("v.selectCheckBoxvalue");
                console.log('temp@@@@@@@@@@'+temp);
            }
        });       
        $A.enqueueAction(checkBoxVal);
    },
    
    save : function(component, event, helper){
        
        //var pklstdefault = "-Please Select-";
        var BrandFieldValueboolean;
        var PkgFieldValueboolean;
        var PkgTypeFieldValueboolean;
        var PkgSizeFieldValueboolean;
        var signFieldValueboolean;
        var ThemeFieldValueboolean;
        var signIDFieldValueboolean;
        var QtyFieldValueboolean;
        
        var BrandField = component.find("BrandID");
        var BrandFieldValue = BrandField.get("v.value");
        
        var PkgField = component.find("PackageID");
        var PkgFieldValue = PkgField.get("v.value");
        
        var PkgTypeField = component.find("packageTypeID");
        var PkgTypeFieldValue = PkgTypeField.get("v.value");
        
        var PkgSizeField = component.find("packageSizeID");
        var PkgSizeFieldValue = PkgSizeField.get("v.value");
        
        var signField = component.find("sign");
        var signFieldValue = signField.get("v.value");
        
        var ThemeField = component.find("ThemeID");
        var ThemeFieldValue = ThemeField.get("v.value");
        
        var signIDField = component.find("signID");
        var signIDFieldValue = signIDField.get("v.value");
        
        var QtyField = component.find("QtyID");
        var QtyFieldValue = QtyField.get("v.value");
        
        
        /*if($A.util.isEmpty(BrandFieldValue)){          
            $A.util.addClass(BrandField, 'haserror');
            BrandField.set('v.errors', [{message:'Please enter a value'}]);
        }else{
            BrandField.set('v.errors', [{message:null}]);
            $A.util.removeClass(BrandField, 'haserror');
            $A.util.addClass(BrandField, 'Noerror');
            component.set("v.selectedBrand",BrandFieldValue);
        }*/
        
        if($A.util.isUndefined(BrandFieldValue) || $A.util.isEmpty(BrandFieldValue)){
            BrandField.showHelpMessageIfInvalid();
             BrandFieldValueboolean = false;
        }
        else{
            component.set("v.selectedBrand",BrandFieldValue);
             BrandFieldValueboolean = true;
            //BrandFieldValue = component.get("v.selectedBrand");
            //alert('BrandFieldValue....'+BrandFieldValue);
        }
        
        
        if($A.util.isUndefined(PkgFieldValue) || $A.util.isEmpty(PkgFieldValue)){
            PkgField.showHelpMessageIfInvalid();
            PkgFieldValueboolean = false;
        }
        else{
            component.set("v.selectedPackage",PkgFieldValue);
             PkgFieldValueboolean = true;
            //PkgFieldValue = component.get("v.selectedPackage");
        }
        
        
        if($A.util.isUndefined(PkgTypeFieldValue) || $A.util.isEmpty(PkgTypeFieldValue)){        
            PkgTypeField.showHelpMessageIfInvalid();
             PkgTypeFieldValueboolean = false;
        }
        else{
            component.set("v.selectedPackgType",PkgTypeFieldValue);
             PkgTypeFieldValueboolean = true;
            //PkgTypeFieldValue = component.get("v.selectedPackgType");
        }
        
        if($A.util.isUndefined(PkgSizeFieldValue) || $A.util.isEmpty(PkgSizeFieldValue)){
            PkgSizeField.showHelpMessageIfInvalid(); 
            PkgSizeFieldValueboolean = false;
        }
        else{
            component.set("v.selectedPckgSizeNew",PkgSizeFieldValue);
             PkgSizeFieldValueboolean = true;
            //PkgSizeFieldValue = component.get("v.selectedPckgSizeNew");
        }
        
        if($A.util.isUndefined(signFieldValue) || $A.util.isEmpty(signFieldValue)){
            signField.showHelpMessageIfInvalid(); 
             signFieldValueboolean = false;
        }
        else{
            component.set("v.selectedSignType",signFieldValue);
             signFieldValueboolean = true;
            //signFieldValue = component.get("v.selectedSignType");
        }
        
        
        /*if($A.util.isUndefined(ThemeFieldValue) || $A.util.isEmpty(ThemeFieldValue)){
            ThemeField.showHelpMessageIfInvalid(); 
            ThemeFieldValueboolean = false;
        }
        else{
            component.set("v.selectedTheme",ThemeFieldValue);
             ThemeFieldValueboolean = true;
            //ThemeFieldValue = component.get("v.selectedTheme");
        }*/
        
        if($A.util.isUndefined(signIDFieldValue) || $A.util.isEmpty(signIDFieldValue)){
            signIDField.showHelpMessageIfInvalid();
            signIDFieldValueboolean = false;
        }
        else{
            component.set("v.selectedSizeNew",signIDFieldValue);
             signIDFieldValueboolean = true;
            //signIDFieldValue = component.get("v.selectedSizeNew");
        }
        
        /*if($A.util.isEmpty(QtyFieldValue)){
            $A.util.addClass(QtyField, 'haserror');
            QtyField.set('v.errors', [{message:'Please enter a value'}]);
        }
        else{
            QtyField.set('v.errors', [{message:null}]);
            $A.util.removeClass(QtyField, 'haserror');
            $A.util.addClass(QtyField, 'Noerror');
            component.set("v.selectedQty",QtyFieldValue);
            QtyFieldValue = component.get("v.selectedQty");
        }*/
        
        if($A.util.isUndefined(QtyFieldValue) || $A.util.isEmpty(QtyFieldValue)){
            QtyField.showHelpMessageIfInvalid();
            QtyFieldValueboolean = false;
        }
        else{
            component.set("v.selectedQty",QtyFieldValue);
            QtyFieldValueboolean = true;
            //QtyFieldValue = component.get("v.selectedQty");
            //alert('QtyFieldValue....'+QtyFieldValue);
        }
        
       // if( BrandFieldValue != null && PkgFieldValue != null && PkgTypeFieldValue != null && 
          // PkgSizeFieldValue != null &&  ThemeFieldValue != null && QtyFieldValue != null &&
          // signIDFieldValue != null && signFieldValue != null )  
          if(BrandFieldValueboolean == true && PkgFieldValueboolean == true && PkgTypeFieldValueboolean == true &&
            PkgSizeFieldValueboolean == true && signFieldValueboolean == true /*&& ThemeFieldValueboolean == true*/ &&
            signIDFieldValueboolean == true && QtyFieldValueboolean == true)         
        {
            var action = component.get("c.createPOS");
            action.setParams({
                WOID:component.get("v.recordId"),
                signType: component.get("v.selectedSignType"),
                selectedSize : component.get("v.selectedSizeNew"),
                selectedTheme : component.get("v.selectedTheme"),
                selectedQty : component.get("v.selectedQty"),
                selectedBrand : component.get("v.selectedBrand"),
                selectedPackg : component.get("v.selectedPackage"),
                selectedPackgType : component.get("v.selectedPackgType"),
                selectedPrice : component.get("v.selectedPrice"),
                selectedPackgSize : component.get("v.selectedPckgSizeNew"),
                selectedChckBoxVal : component.get("v.selectCheckBoxvalue")
            });
            action.setCallback(this, function(response) {
                if(response.getState() == "SUCCESS"){
                    //Fire
                }
            }); 
            $A.enqueueAction(action);
            $A.get("e.force:closeQuickAction").fire(); 
            
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                title: 'Success Message',
                message: 'Custom POS was created successfully',
                duration:' 1000',
                key: 'info_alt',
                type: 'success',
                mode: 'dismissible'
            });
            toastEvent.fire();
            
            var navEvent = $A.get("e.force:navigateToSObject");
            navEvent.setParams({
                //recordId: "aAJm00000004JrHGAU",
                recordId: component.get("v.recordId"),
                slideDevName: "detail"
            });
            navEvent.fire(); 
            
           location.reload(true);
        }
        
    },
    
    cancel : function(component, event, helper) {
        $A.get("e.force:closeQuickAction").fire();
    },
    
    showSpinner: function(component, event, helper) {
        // make Spinner attribute true for display loading spinner 
        component.set("v.Spinner", true); 
    },
    
    hideSpinner : function(component,event,helper){
        // make Spinner attribute to false for hide loading spinner    
        component.set("v.Spinner", false);
    }    
})