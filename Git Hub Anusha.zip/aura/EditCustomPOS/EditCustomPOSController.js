({
    doInit : function(component, event, helper){
        
        // To Capture Prior Values
        var priorVal = component.get("c.getValues");
        priorVal.setParams({
            POSID:component.get("v.recordId")
        }); 
        priorVal.setCallback(this, function(response){
            if(response.getState() == "SUCCESS"){
                component.set("v.CustomPOSVal",response.getReturnValue());
            }
        });   
        $A.enqueueAction(priorVal);
        
        //To Capture Package
        var packageaction = component.get("c.getPackage");
        packageaction.setParams({
            POSID:component.get("v.recordId")
        }); 
        packageaction.setCallback(this, function(response){
            if(response.getState() == "SUCCESS"){
                var selectedPkgNewVal = component.get('v.CustomPOSVal.Package__c');
                console.log('selectedPkgNewVal....'+selectedPkgNewVal);
                var PkgLst = response.getReturnValue();
                var indexVal = PkgLst.indexOf(selectedPkgNewVal);
                PkgLst.splice(indexVal, 1);
                PkgLst.unshift(selectedPkgNewVal);
                component.set("v.packageLst",PkgLst);
            }
        });
        $A.enqueueAction(packageaction);
        
        //To Capture Package Type
        var PkgTypeaction = component.get("c.getPriorPkgTypeVal");
        //var selectedPkgvar = component.get('v.CustomPOSVal.Package__c');
        //console.log('selectedPkgvar....'+selectedPkgvar);
        PkgTypeaction.setParams({
            "POSID" : component.get('v.recordId')
            //"PkgName" : selectedPkgvar
        }); 
        PkgTypeaction.setCallback(this, function(response){
            if(response.getState() == "SUCCESS"){
                //component.set("v.packageTypeLst",response.getReturnValue());
                
                var selectedPkgTypeNewVal = component.get('v.CustomPOSVal.Package_Type__c');
                console.log('selectedPkgTypeNewVal....'+selectedPkgTypeNewVal);
                var PkgTypeLst = response.getReturnValue();
                var indexVal = PkgTypeLst.indexOf(selectedPkgTypeNewVal);
                PkgTypeLst.splice(indexVal, 1);
                PkgTypeLst.unshift(selectedPkgTypeNewVal);
                component.set("v.packageTypeLst",PkgTypeLst);
            }
        });       
        $A.enqueueAction(PkgTypeaction);
        
        //To capture Package Size
        var Pkgsizeaction = component.get("c.getPriorPkgSizeVal");
        //var selectedPkgTypevar = component.get('v.CustomPOSVal.Package_Type__c');
        //console.log('selectedPkgTypevar....'+selectedPkgTypevar);
        //component.set("v.selectedPackgType",selectedPkgTypevar);
        Pkgsizeaction.setParams({
            "POSID" : component.get('v.recordId')
            //"PkgTypeName" : selectedPkgTypevar
        }); 
        Pkgsizeaction.setCallback(this, function(response){
            if(response.getState() == "SUCCESS"){
                //component.set("v.packageSizeLst",response.getReturnValue());
                
                var selectedPkgSizeNewVal = component.get('v.CustomPOSVal.Package_Size__c');
                console.log('selectedPkgSizeNewVal....'+selectedPkgSizeNewVal);
                var PkgSizeLst = response.getReturnValue();
                var indexVal = PkgSizeLst.indexOf(selectedPkgSizeNewVal);
                PkgSizeLst.splice(indexVal, 1);
                PkgSizeLst.unshift(selectedPkgSizeNewVal);
                component.set("v.packageSizeLst",PkgSizeLst);
            }
        });       
        $A.enqueueAction(Pkgsizeaction);
        
        //To capture Sign Type
        var action = component.get("c.getSigntype");
        action.setParams({
            "POSID" : component.get('v.recordId')
        }); 
        action.setCallback(this, function(response){
            if(response.getState() == "SUCCESS"){
                //component.set("v.signTypeLst",response.getReturnValue());
                
                var selectedSignTypeNewVal = component.get('v.CustomPOSVal.Sign_Type__c');
                console.log('selectedSignTypeNewVal....'+selectedSignTypeNewVal);
                var SignTypeLst = response.getReturnValue();
                var indexVal = SignTypeLst.indexOf(selectedSignTypeNewVal);
                SignTypeLst.splice(indexVal, 1);
                SignTypeLst.unshift(selectedSignTypeNewVal);
                component.set("v.signTypeLst",SignTypeLst);
            }
        });
        $A.enqueueAction(action); 
        
        //To capture Theme
        var themeaction = component.get("c.getTheme");
        themeaction.setParams({
            "POSID" : component.get('v.recordId')
        }); 
        themeaction.setCallback(this, function(response){
            if(response.getState() == "SUCCESS"){                      
                
                var selectedThemeNewVal = component.get('v.CustomPOSVal.Theme__c');
                console.log('selectedThemeNewVal....'+selectedThemeNewVal);
                var ThemeLst = response.getReturnValue();
                var indexVal = ThemeLst.indexOf(selectedThemeNewVal);
                ThemeLst.splice(indexVal, 1);
                ThemeLst.unshift(selectedThemeNewVal);
                component.set("v.themeLst",ThemeLst);
            }
        }); 
        $A.enqueueAction(themeaction);
        
        //To capture Selected Size(WXH)
        var sizeaction = component.get("c.getPriorSizeVal");
        //var selectedSignTypevar = component.get('v.CustomPOSVal.Sign_Type__c');
        //console.log('selectedSignTypevar....'+selectedSignTypevar);
        sizeaction.setParams({
            "POSID" : component.get('v.recordId')
            //  "SignTypeName" : selectedSignTypevar
        }); 
        sizeaction.setCallback(this, function(response){
            if(response.getState() == "SUCCESS"){
                //component.set("v.sizeLst",response.getReturnValue());
                
                var selectedSizeVal = component.get('v.CustomPOSVal.Size__c');
                console.log('selectedSizeVal....'+selectedSizeVal);
                var SizeLst = response.getReturnValue();
                var indexVal = SizeLst.indexOf(selectedSizeVal);
                SizeLst.splice(indexVal, 1);
                SizeLst.unshift(selectedSizeVal);
                component.set("v.sizeLst",SizeLst);
            }
        });       
        $A.enqueueAction(sizeaction);
        
        //To capture checkbox Values
        var checkboxVal = component.get("c.getPriorCheckBoxVal");
        //var selectedSignTypevar = component.get('v.CustomPOSVal.Sign_Type__c');
        checkboxVal.setParams({
            "POSID" : component.get('v.recordId')
            //"SignTypeName" : selectedSignTypevar
        });
        checkboxVal.setCallback(this, function(response){
            if(response.getState() == "SUCCESS"){
                component.set("v.checkBoxOptions",response.getReturnValue());
                
                /*var selectedcheckBoxVal = component.get('v.CustomPOSVal.Option__c');
                console.log('selectedcheckBoxVal....'+selectedcheckBoxVal);
                var CheckBoxLst = response.getReturnValue();
                var indexVal = CheckBoxLst.indexOf(selectedcheckBoxVal);
                CheckBoxLst.splice(indexVal, 1);
                CheckBoxLst.unshift(selectedcheckBoxVal);
                component.set("v.checkBoxOptions",CheckBoxLst);*/
                
            }
        });       
        $A.enqueueAction(checkboxVal);
        
        
    }, //Do Init End
    
    getBrand : function(component, event, helper){
        var selectedBrandVar = component.find('BrandID').get('v.value'); 
        component.set("v.selectedBrand",selectedBrandVar);
    },
    
   /* getBrand : function(component, event, helper){
        var BrandField = component.find("BrandID");
        var BrandFieldValue = BrandField.get("v.value");
        if($A.util.isEmpty(BrandFieldValue)){
            //$A.util.addClass(BrandField, 'slds-has-error');
            $A.util.addClass(BrandField, 'haserror');
            BrandField.set('v.errors', [{message:'Please enter a value'}]);
        }else{
            BrandField.set('v.errors', [{message:null}]);
            //$A.util.removeClass(BrandField, 'slds-has-error');
            $A.util.removeClass(BrandField, 'haserror');
            $A.util.addClass(BrandField, 'Noerror');
            component.set("v.selectedBrand",BrandFieldValue);
        }
        
        
    },*/
    
    getQty : function(component, event, helper){
        var selectedQtyvar = component.find("QtyID").get("v.value");
        component.set("v.selectedQty",selectedQtyvar);
    },
    
    getPrice : function(component, event, helper){
        var selectedPriceVar = component.find('PriceID').get('v.value');
        component.set("v.selectedPrice",selectedPriceVar);
    },
    
    onPackageChange : function(component, event, helper){
        //setting to null
        component.set("v.packageTypeLst","");
        component.set("v.packageSizeLst","");
        
        var selectedPackageVar = component.find('PackageID').get('v.value');
        component.set("v.PkgID",selectedPackageVar);
        
        var packaction = component.get('c.getSelectedPackage');
        packaction.setParams({
            "POSID" : component.get('v.recordId'),
            "pckgID" : selectedPackageVar
        }); 
        packaction.setCallback(this, function(response){
            if(response.getState() == "SUCCESS"){
                
                var tempLast = response.getReturnValue();
                //alert('tempLast...'+tempLast);
                var cmpEvent= component.getEvent("pcklstvalue");
                cmpEvent.setParams({"pckListValue":tempLast[0]});
                var con = cmpEvent.getParam("pckListValue");
                //alert('con@@@@@@@@'+con);
                //component.set("v.packageTypeLst",response.getReturnValue());
                
                
                var tempLast = response.getReturnValue();
                var selPkgSizeVal = tempLast[0];
                var PkgTypeLst = response.getReturnValue();
                var indexVal = PkgTypeLst.indexOf(selPkgSizeVal);
                PkgTypeLst.splice(indexVal, 1);
                PkgTypeLst.unshift(selPkgSizeVal);
                //alert('PkgTypeLst....'+PkgTypeLst);
                
                component.set("v.packageTypeLst",PkgTypeLst);
                component.set("v.PkgTypeID",con);
                
                // var actionpkgSizeLst = component.get('c.getpkgSizeLst');
                var actionpkgSizeLst = component.get('c.getSelectedPckgType');
                actionpkgSizeLst.setParams({
                    //"PkgTypeID" : component.get("v.PkgTypeID")
                    
                    //new Added
                    "PkgID" : selectedPackageVar,
                    "pckgTypeID" : component.get('v.PkgTypeID'),
                    "POSID" : component.get('v.recordId')
                }); 
                actionpkgSizeLst.setCallback(this, function(response){
                    if(response.getState() == "SUCCESS"){
                        var tempLast = response.getReturnValue();
                        var cmpEvent= component.getEvent("pcklstvalue");
                        cmpEvent.setParams({"PkgSizeVal":tempLast[0]});
                        var con = cmpEvent.getParam("PkgSizeVal");
                        //alert('con@@@@@@@@PkgSize...'+con);
                        
                        component.set("v.packageSizeLst",response.getReturnValue());
                        component.set("v.PkgSizeID",con);
                    }
                });
                $A.enqueueAction(actionpkgSizeLst);
            }
        });       
        $A.enqueueAction(packaction);
    },
    
    onPackageTypeChange : function(component, event, helper){
        component.set("v.packageSizeLst","");
        
        var selectedPackageVar = component.find('PackageID').get('v.value');
        //alert('selectedPackageVar...'+selectedPackageVar);
        var selectedPackageTypeVar = component.find('PackageTypeID').get('v.value');
        //alert(selectedPackageTypeVar);
        component.set("v.PkgTypeID",selectedPackageTypeVar);
        
        var pckgTypeaction = component.get('c.getSelectedPckgType');
        pckgTypeaction.setParams({
            "PkgID" : selectedPackageVar,
            "pckgTypeID" : component.get('v.PkgTypeID'),
            "POSID" : component.get('v.recordId')
        }); 
        pckgTypeaction.setCallback(this, function(response){
            if(response.getState() == "SUCCESS"){
                
                var tempLast = response.getReturnValue();
                var cmpEvent= component.getEvent("pcklstvalue");
                cmpEvent.setParams({"PkgSizeVal":tempLast[0]});
                var con = cmpEvent.getParam("PkgSizeVal");
                //alert('con@@@@@@@@PkgSize...'+con);
                component.set("v.packageSizeLst",response.getReturnValue());
                component.set("v.PkgSizeID",con);
                
            }
        });       
        $A.enqueueAction(pckgTypeaction);
    },
    
    getSelectedPackgSize : function(component, event, helper){
        var selectedPackageSizeVar = component.find('packageSizeID').get('v.value');
        //alert('selectedPackageSizeVar....'+selectedPackageSizeVar);
        component.set("v.PkgSizeID",selectedPackageSizeVar);
    },
    
    onSignTypeChange : function(component, event, helper){
        var selectedSignTypevar = component.find("sign").get("v.value");
        //alert('selectedSignTypevar!!!!!! '+selectedSignTypevar);
        component.set("v.selectedSignType",selectedSignTypevar);
        
        var sizeaction = component.get("c.getSize");
        sizeaction.setParams({
            "POSID" : component.get('v.recordId'),
            "SignType" : component.get("v.selectedSignType")
        });       
        sizeaction.setCallback(this, function(response){
            if(response.getState() == "SUCCESS"){
                
                var tempLast = response.getReturnValue();
                var cmpEvent= component.getEvent("pcklstvalue");
                cmpEvent.setParams({"SizeVal":tempLast[0]});
                var SizeValVar = cmpEvent.getParam("SizeVal");
                //alert('SizeValVar@@@@@@@@'+SizeValVar);
                component.set('v.selectedSizeVal',SizeValVar);
                component.set("v.sizeLst",response.getReturnValue());
            }
        });       
        $A.enqueueAction(sizeaction);
        
        var checkboxVal = component.get("c.getCheckBoxVal");
        checkboxVal.setParams({
            "POSID" : component.get('v.recordId'),
            "SignType" : component.get("v.selectedSignType")
        });
        checkboxVal.setCallback(this, function(response){
            if(response.getState() == "SUCCESS"){
                component.set("v.checkBoxOptions",response.getReturnValue());
                //var temp = JSON.stringify(component.get("v.checkBoxOptions"));
                //console.log('temp.....'+temp);
            }
        });       
        $A.enqueueAction(checkboxVal);
    },
    
    onThemeChange : function(component, event, helper){
        var selectedThemevar = component.find("ThemeID").get("v.value");
        component.set("v.selectedTheme",selectedThemevar);
    },
    
    getSelectedSize : function(component, event, helper){
        var sizeVal = component.find("signID").get("v.value");
        //alert('sizeVal@@@@@@'+sizeVal);
        component.set('v.selectedSizeVal',sizeVal);
    },
    
    checkBoxSel : function(component, event, helper){
        var checkBoxVal = component.get('c.selectedChckBoxVal');
        component.set('v.ChckValBol',true);
        checkBoxVal.setParams({
            "Options" : JSON.stringify(component.get('v.checkBoxOptions'))
        }); 
        checkBoxVal.setCallback(this, function(response){
            if(response.getState() == "SUCCESS"){
                component.set("v.selectCheckBoxvalue",response.getReturnValue());
                var temp = component.get("v.selectCheckBoxvalue");
                console.log('temp@@@@@@@@@@'+temp);
            }
        });       
        $A.enqueueAction(checkBoxVal);
    },
    
    updatePOS : function(component, event, helper){
        
        var BrandFieldValueboolean;
        var BrandField = component.find("BrandID");
        var BrandFieldValue = BrandField.get("v.value");
        
        var QtyFieldValueboolean;
        var QtyField = component.find("QtyID");
        var QtyFieldValue = QtyField.get("v.value");

        
        if($A.util.isUndefined(BrandFieldValue) || $A.util.isEmpty(BrandFieldValue)){
            BrandField.showHelpMessageIfInvalid();
             BrandFieldValueboolean = false;
        }
        else{
            component.set("v.selectedBrand",BrandFieldValue);
             BrandFieldValueboolean = true;
        }
        
        if($A.util.isUndefined(QtyFieldValue) || $A.util.isEmpty(QtyFieldValue)){
            QtyField.showHelpMessageIfInvalid();
            QtyFieldValueboolean = false;
        }
        else{
            component.set("v.selectedQty",QtyFieldValue);
            QtyFieldValueboolean = true;
        }
        
        if(BrandFieldValueboolean == true && QtyFieldValueboolean == true){
                
                var action = component.get("c.updateCreatedPOS");
                action.setParams({
                POSID : component.get("v.recordId"),
                selectedBrand : component.get("v.selectedBrand"), 
                PkgId : component.get("v.PkgID"),
                PkgTypeId : component.get("v.PkgTypeID"),
                PkgSizeVal : component.get("v.PkgSizeID"),
                selectedQty : component.get("v.selectedQty"),
                selectedPrice : component.get("v.selectedPrice"),
                selectedTheme : component.get("v.selectedTheme"),
                selectedChckBoxVal : component.get("v.selectCheckBoxvalue"),
                SizeValVar : component.get("v.selectedSizeVal"),
                selectedSignTypeVal : component.get("v.selectedSignType"),
                booleanCheck : component.get("v.ChckValBol")
            });
            action.setCallback(this, function(response) {
                if(response.getState() == "SUCCESS"){
                    //alert(response.getReturnValue());
                }
            }); 
            $A.enqueueAction(action);
            $A.get("e.force:closeQuickAction").fire();  
            
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                title: 'Success Message',
                message: 'Custom POS was updated successfully',
                duration:' 1000',
                key: 'info_alt',
                type: 'success',
                mode: 'dismissible'
            });
            toastEvent.fire();
            
            var navEvent = $A.get("e.force:navigateToSObject");
            navEvent.setParams({
                //recordId: "aAJm00000004JrHGAU",
                recordId: component.get("v.recordId"),
                slideDevName: "detail"
            });
            navEvent.fire(); 
            
            
            location.reload(true);
        }
        
    },
    
    cancel : function(component, event, helper) {
        $A.get("e.force:closeQuickAction").fire();
    },
    
    showSpinner: function(component, event, helper) {
        // make Spinner attribute true for display loading spinner 
        component.set("v.Spinner", true); 
    },
    
    hideSpinner : function(component,event,helper){
        // make Spinner attribute to false for hide loading spinner    
        component.set("v.Spinner", false);
    }   
})