({
    doInit : function(component, event, helper){
        // To Capture Prior Values
        var priorVal = component.get("c.getValues");
        priorVal.setParams({
            POSID:component.get("v.recordId")
        }); 
        priorVal.setCallback(this, function(response){
            if(response.getState() == "SUCCESS"){
                component.set("v.CustomPOSVal",response.getReturnValue());
            }
        });   
        $A.enqueueAction(priorVal);  
    },
    
    Delete : function(component, event, helper){
        var action = component.get("c.getRecord");
        action.setParams({
            POSID:component.get("v.recordId")
        }); 
        action.setCallback(this, function(response){
            if(response.getState() == "SUCCESS"){
                
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title: 'Success Message',
                    message: 'Custom POS has been deleted successfully',
                    duration:' 1000',
                    key: 'info_alt',
                    type: 'success',
                    mode: 'dismissible'
                });
                toastEvent.fire();
                
                
                //var urlWO = response.getReturnValue();
                var navEvent = $A.get("e.force:navigateToSObject");
                navEvent.setParams({
                    //recordId: "aAJm00000004JrHGAU",
                    recordId: component.get('v.CustomPOSVal.Work_Order__c'),
                    slideDevName: "detail"
                });
                navEvent.fire(); 
            location.reload(true);   
            }
        });
        $A.enqueueAction(action);  
   
    },
    
    Cancel : function(component, event, helper) {
        $A.get("e.force:closeQuickAction").fire();
    }  
})